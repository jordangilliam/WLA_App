package com.bakar.assest.opengl;

import javax.media.opengl.GL;

public interface DrawableGlObject {
    void draw(GL gl);
}
